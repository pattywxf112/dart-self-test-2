void main() {
  var list = [2, 4, 6,8];
  list.forEach((item) => print(item * 2));
}

// void main() {
//   var list = [2, 4, 6, 8];

//   list.forEach((num) {
//     print(num * 2);
//   });
// }